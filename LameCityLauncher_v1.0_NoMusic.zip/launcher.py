
import sys
import webbrowser
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtCore import Qt

SERVER_IP = "fivem://connect/dqz8gy"
DISCORD_LINK = "https://discord.gg/gZYdsYCy"

class Launcher(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🌆 Lame City Launcher")
        self.setFixedSize(500, 600)
        self.setStyleSheet("background-color: #1e1e1e; color: white;")

        layout = QVBoxLayout()

        # Logo
        logo = QLabel()
        pixmap = QPixmap("assets/lamecity_logo.png").scaled(200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        logo.setPixmap(pixmap)
        logo.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo)

        # Tiêu đề
        title = QLabel("Chào mừng đến Lame City")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Nút Vào Thành Phố
        join_button = QPushButton("🚀 Vào Thành Phố")
        join_button.setStyleSheet("padding: 15px; font-size: 16px; background-color: #0f62fe; color: white; border-radius: 10px;")
        join_button.clicked.connect(self.join_server)
        layout.addWidget(join_button)

        # Nút Discord
        discord_button = QPushButton("💬 Tham gia Discord")
        discord_button.setStyleSheet("padding: 10px; font-size: 14px; background-color: #5865F2; color: white; border-radius: 10px;")
        discord_button.clicked.connect(lambda: webbrowser.open(DISCORD_LINK))
        layout.addWidget(discord_button)

        self.setLayout(layout)

    def join_server(self):
        webbrowser.open(SERVER_IP)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    launcher = Launcher()
    launcher.show()
    sys.exit(app.exec_())
